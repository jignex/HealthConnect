const express = require("express");
const router = express.Router();

const db = require("../db");
const authenticateToken = require("../middleware/auth");

// =====================================================
// GET LOGGED-IN USER PROFILE
// GET /api/users/profile
// =====================================================

router.get("/profile", authenticateToken, async (req, res) => {
    try {

        const userId = req.user.id;

        const [rows] = await db.query(
            `SELECT 
                id,
                name,
                email,
                phone,
                city,
                blood_group,
                address,
                role,
                created_at
             FROM users
             WHERE id = ?`,
            [userId]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        res.json({
            user: rows[0]
        });

    } catch (error) {

        console.error("Profile error:", error);

        res.status(500).json({
            message: "Server error"
        });
    }
});


// =====================================================
// UPDATE LOGGED-IN USER PROFILE
// PUT /api/users/profile
// =====================================================

router.put("/profile", authenticateToken, async (req, res) => {
    try {

        const userId = req.user.id;

        const {
            name,
            email,
            phone,
            city,
            blood_group,
            address
        } = req.body;

        // -----------------------------
        // Basic validation
        // -----------------------------

        if (!name || !email) {
            return res.status(400).json({
                error: "Name and email are required"
            });
        }

        // -----------------------------
        // Update user in database
        // -----------------------------

        await db.query(
            `UPDATE users
             SET
                name = ?,
                email = ?,
                phone = ?,
                city = ?,
                blood_group = ?,
                address = ?
             WHERE id = ?`,
            [
                name.trim(),
                email.trim(),
                phone ? phone.trim() : "",
                city ? city.trim() : "",
                blood_group ? blood_group.trim() : "",
                address ? address.trim() : "",
                userId
            ]
        );

        // -----------------------------
        // Get updated user
        // -----------------------------

        const [rows] = await db.query(
            `SELECT
                id,
                name,
                email,
                phone,
                city,
                blood_group,
                address,
                role,
                created_at
             FROM users
             WHERE id = ?`,
            [userId]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                error: "User not found"
            });
        }

        // -----------------------------
        // Send updated user to frontend
        // -----------------------------

        res.json({
            message: "Profile updated successfully",
            user: rows[0]
        });

    } catch (error) {

        console.error("Profile update error:", error);

        res.status(500).json({
            error: "Server error while updating profile"
        });
    }
});


module.exports = router;