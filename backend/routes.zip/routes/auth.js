const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');

const router = express.Router();

const VALID_ROLES = [
    'user',
    'donor',
    'pharmacy',
    'oxygen',
    'doctor',
    'hospital'
];


// =====================================================
// REGISTER
// =====================================================

router.post('/register', async (req, res) => {

    try {

        const {
            name,
            email,
            password,
            phone,
            city,
            role
        } = req.body;


        const selectedRole = role || 'user';


        // Validate role
        if (!VALID_ROLES.includes(selectedRole)) {

            return res.status(400).json({
                error: 'Invalid account type'
            });

        }


        // Required fields
        if (!name || !email || !password) {

            return res.status(400).json({
                error: 'Name, email and password are required'
            });

        }


        // Check existing email
        const [existing] = await db.query(
            'SELECT id FROM users WHERE email = ?',
            [email]
        );


        if (existing.length > 0) {

            return res.status(400).json({
                error: 'Email already registered'
            });

        }


        // Hash password
        const passwordHash =
            await bcrypt.hash(password, 10);


        // Create account
        const [result] = await db.query(
            `INSERT INTO users
            (
                name,
                email,
                password_hash,
                phone,
                city,
                role
            )
            VALUES (?, ?, ?, ?, ?, ?)`,
            [
                name,
                email,
                passwordHash,
                phone || null,
                city || null,
                selectedRole
            ]
        );


        res.status(201).json({

            message: 'Registered successfully',

            user: {
                id: result.insertId,
                name,
                email,
                role: selectedRole
            }

        });


    } catch (err) {

        console.error('Registration error:', err);

        res.status(500).json({
            error: 'Server error'
        });

    }

});


// =====================================================
// LOGIN
// =====================================================

router.post('/login', async (req, res) => {

    try {

        const {
            email,
            password,
            role
        } = req.body;


        if (!email || !password) {

            return res.status(400).json({
                error: 'Email and password are required'
            });

        }


        if (!role) {

            return res.status(400).json({
                error: 'Account type is required'
            });

        }


        if (!VALID_ROLES.includes(role)) {

            return res.status(400).json({
                error: 'Invalid account type'
            });

        }


        // Find account
        const [rows] = await db.query(
            `SELECT
                id,
                name,
                email,
                password_hash,
                phone,
                city,
                role
             FROM users
             WHERE email = ?`,
            [email]
        );


        if (rows.length === 0) {

            return res.status(401).json({
                error: 'Invalid email or password'
            });

        }


        const user = rows[0];


        // Check password
        const validPassword =
            await bcrypt.compare(
                password,
                user.password_hash
            );


        if (!validPassword) {

            return res.status(401).json({
                error: 'Invalid email or password'
            });

        }


        // Check selected account type
        if (user.role !== role) {

            return res.status(403).json({
                error:
                    `This account is registered as ${user.role}, not ${role}.`
            });

        }


        // Create JWT
        const token = jwt.sign(

            {
                id: user.id,
                role: user.role
            },

            process.env.JWT_SECRET,

            {
                expiresIn: '7d'
            }

        );


        // Send response
        res.json({

            message: 'Login successful',

            token,

            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                city: user.city,
                role: user.role
            }

        });


    } catch (err) {

        console.error('Login error:', err);

        res.status(500).json({
            error: 'Server error'
        });

    }

});


module.exports = router;