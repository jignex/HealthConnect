const express = require('express');
const db = require('../db');

const router = express.Router();


// =====================================================
// SEARCH AVAILABLE BLOOD
// GET /api/blood/search?bloodGroup=O%2B&city=Mumbai
// =====================================================

router.get('/search', async (req, res) => {

  try {

    const { bloodGroup, city } = req.query;

    if (!bloodGroup || !city) {
      return res.status(400).json({
        error: 'bloodGroup and city are required'
      });
    }

    // =====================================================
    // 1. SEARCH BLOOD RECORDS
    // =====================================================

    const [bloodRecords] = await db.query(
      `SELECT
          id,
          name,
          blood_group,
          city,
          units,
          contact_phone
       FROM blood_records
       WHERE blood_group = ?
         AND city LIKE ?
         AND units > 0
       ORDER BY id DESC`,
      [
        bloodGroup,
        `%${city}%`
      ]
    );

    // =====================================================
    // 2. SEARCH REAL REGISTERED AVAILABLE DONORS
    // =====================================================

    const [donors] = await db.query(
      `SELECT
          d.id,
          d.user_id,
          u.name,
          u.email,
          d.blood_group,
          d.age,
          d.gender,
          d.phone AS contact_phone,
          d.city,
          d.address,
          d.availability_status,
          d.last_donation_date,
          d.created_at
       FROM donors d
       INNER JOIN users u
          ON d.user_id = u.id
       WHERE d.blood_group = ?
         AND d.city LIKE ?
         AND d.availability_status = 'Available'
       ORDER BY d.created_at DESC`,
      [
        bloodGroup,
        `%${city}%`
      ]
    );

    // =====================================================
    // 3. CONVERT DONORS TO THE SAME RESULT FORMAT
    // =====================================================

    const donorResults = donors.map(donor => ({

      id: `donor-${donor.id}`,
      name: donor.name,
      email: donor.email,
      blood_group: donor.blood_group,
      age: donor.age,
      gender: donor.gender,
      city: donor.city,
      address: donor.address,
      units: 1,
      contact_phone: donor.contact_phone,
      availability_status: donor.availability_status,
      last_donation_date: donor.last_donation_date,
      source: 'donor'

    }));

    // =====================================================
    // 4. CONVERT BLOOD RECORDS TO RESULT FORMAT
    // =====================================================

    const bloodResults = bloodRecords.map(record => ({

      id: `blood-${record.id}`,
      name: record.name,
      blood_group: record.blood_group,
      city: record.city,
      units: record.units,
      contact_phone: record.contact_phone,
      source: 'blood_record',
      availability_status: 'Available'

    }));

    // =====================================================
    // 5. COMBINE BLOOD RECORDS + DONORS
    // =====================================================

    const results = [
      ...bloodResults,
      ...donorResults
    ];

    // =====================================================
    // 6. RETURN RESULTS
    // =====================================================

    res.json({
      available: results.length > 0,
      results: results
    });

  } catch (err) {

    console.error(
      "Blood search error:",
      err
    );

    res.status(500).json({
      error: 'Server error while searching blood'
    });

  }

});


// =====================================================
// CREATE A BLOOD REQUEST
// POST /api/blood/request
// =====================================================

router.post('/request', async (req, res) => {

  try {

    const {
      userId,
      bloodGroup,
      city,
      units,
      urgency
    } = req.body;

    await db.query(
      `INSERT INTO blood_requests
       (user_id, blood_group, city, units, urgency)
       VALUES (?, ?, ?, ?, ?)`,
      [
        userId || null,
        bloodGroup,
        city,
        units || 1,
        urgency || 'Normal'
      ]
    );

    res.status(201).json({
      message: 'Blood request created'
    });

  } catch (err) {

    console.error(
      "Blood request error:",
      err
    );

    res.status(500).json({
      error: 'Server error'
    });

  }

});


// =====================================================
// GET PENDING BLOOD REQUESTS
// GET /api/blood/requests
// =====================================================

router.get('/requests', async (req, res) => {

  try {

    const [rows] = await db.query(
      `SELECT *
       FROM blood_requests
       WHERE status = 'Pending'
       ORDER BY created_at DESC`
    );

    res.json({
      requests: rows
    });

  } catch (err) {

    console.error(
      "Blood requests error:",
      err
    );

    res.status(500).json({
      error: 'Server error'
    });

  }

});


// =====================================================
// UPDATE BLOOD REQUEST STATUS
// PATCH /api/blood/requests/:id
// =====================================================

router.patch('/requests/:id', async (req, res) => {

  try {

    const { id } = req.params;
    const { status } = req.body;

    await db.query(
      `UPDATE blood_requests
       SET status = ?
       WHERE id = ?`,
      [
        status,
        id
      ]
    );

    res.json({
      message: 'Request updated'
    });

  } catch (err) {

    console.error(
      "Blood request update error:",
      err
    );

    res.status(500).json({
      error: 'Server error'
    });

  }

});


module.exports = router;
